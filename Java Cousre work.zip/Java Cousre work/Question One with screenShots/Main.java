public class main{
    public static void main(String[] args) {
        Animal lion = new Lion("Leo", 5);
        Animal elephant = new Elephant("Ella", 10);
        Animal monkey = new Monkey("Momo", 3);

        System.out.println("*************************************\n");
        System.out.println("Lion: " + lion.getName() + ", Age : " + lion.getAge());
        lion.makeSound();
        lion.eat();
        lion.makeSound(3);
        System.out.println("*************************************\n");

        System.out.println("*************************************\n");
        System.out.println("Elephant: " + elephant.getName() + ", Age :"+ elephant.getAge());
        elephant.makeSound();
        elephant.eat();
        elephant.makeSound(2);
        System.out.println("*************************************\n");

        System.out.println("*************************************\n");
        System.out.println("Monkey: " + monkey.getName() + ", Age :"+ monkey.getAge());
        monkey.makeSound();
        monkey.eat();
        monkey.makeSound(4);
        System.out.println("*************************************\n");
    }
}