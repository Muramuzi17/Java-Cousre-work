public class Monkey extends Animal {
    public Monkey(String name, int age) {
        super(name, age);
    }

    @Override
    public void makeSound() {
        System.out.println("=========================");
        System.out.println("Animal sound : Roar");
    }

    @Override
    public void eat() {
        System.out.println("Animal eats : Meat");
        System.out.println("=========================");
    }
}
