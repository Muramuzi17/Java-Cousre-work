import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class LibraryManagementSystem extends JFrame {
    private JTextField txtBookID, txtTitle, txtAuthor, txtYear;
    private JButton btnAdd, btnDelete, btnRefresh;
    private JTable table;
    private DefaultTableModel tableModel;
    private Connection connection;

    public LibraryManagementSystem() {
        setTitle("Library Management System");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Text Fields
        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        inputPanel.add(new JLabel("Book ID:"));
        txtBookID = new JTextField();
        inputPanel.add(txtBookID);
        inputPanel.add(new JLabel("Title:"));
        txtTitle = new JTextField();
        inputPanel.add(txtTitle);
        inputPanel.add(new JLabel("Author:"));
        txtAuthor = new JTextField();
        inputPanel.add(txtAuthor);
        inputPanel.add(new JLabel("Year:"));
        txtYear = new JTextField();
        inputPanel.add(txtYear);

        // Buttons
        btnAdd = new JButton("Add Book");
        btnDelete = new JButton("Delete Book");
        btnRefresh = new JButton("Refresh List");

        // Table
        String[] columns = {"Book ID", "Title", "Author", "Year"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnRefresh);

        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Button Listeners
        btnAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addBook();
            }
        });

        btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteBook();
            }
        });

        btnRefresh.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshList();
            }
        });

        // Connect to the Database
        connectToDatabase();
    }

    // private void connectToDatabase() {
    //     try {
    //         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    //         String url = "C:/Users/Albert Altech/Desktop/Java Cousre work/database.accdb";
    //         connection = DriverManager.getConnection(url);
    //     } catch (ClassNotFoundException | SQLException e) {
    //         e.printStackTrace();
    //         JOptionPane.showMessageDialog(null, "Failed to connect to the database.");
    //     }
    // }


        private void connectToDatabase() {
        try {
            // Load the UCanAccess JDBC driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            // Database URL (replace with your actual database file path)
            String url = "./database.accdb";

            // Establish the database connection
            connection = DriverManager.getConnection(url);

            JOptionPane.showMessageDialog(null, "Connected to the database.");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load the UCanAccess JDBC driver.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to connect to the database: " + e.getMessage());
        }

        }
    private void addBook() {
        try {
            String query = "INSERT INTO Books (BookID, Title, Author, Year) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, txtBookID.getText());
            statement.setString(2, txtTitle.getText());
            statement.setString(3, txtAuthor.getText());
            statement.setString(4, txtYear.getText());
            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Book added successfully.");
            refreshList();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to add book.");
        }
    }

    private void deleteBook() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a book to delete.");
            return;
        }
        String bookID = (String) table.getValueAt(selectedRow, 0);
        try {
            String query = "DELETE FROM Books WHERE BookID = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, bookID);
            statement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Book deleted successfully.");
            refreshList();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to delete book.");
        }
    }

    private void refreshList() {
        tableModel.setRowCount(0); // Clear existing rows
        try {
            String query = "SELECT * FROM Books";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String bookID = resultSet.getString("BookID");
                String title = resultSet.getString("Title");
                String author = resultSet.getString("Author");
                String year = resultSet.getString("Year");
                tableModel.addRow(new String[]{bookID, title, author, year});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to refresh book list.");
        }
    }
}
